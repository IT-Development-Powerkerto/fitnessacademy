<?php

namespace App\Http\Livewire\Lp;

use Livewire\Component;

class Navbar extends Component
{
    public function render()
    {
        return view('livewire.lp.navbar');
    }
}
